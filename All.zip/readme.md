<h2>Phone selling website! <img src="https://media.giphy.com/media/12oufCB0MyZ1Go/giphy.gif" width="50"></h2>
<img align='right' src="https://media.giphy.com/media/M9gbBd9nbDrOTu1Mqx/giphy.gif" width="230">
<p><em>VinhKyIT - HoangTrieu - ThayPhapHuTi <img src="https://media.giphy.com/media/WUlplcMpOCEmTGBtBW/giphy.gif" width="30"> 
</em></p>

![Twitter Follow](https://img.shields.io/twitter/follow/HackerJax?label=Follow)
<img src="https://visitor-badge.glitch.me/badge?page_id=vinhkyit.do-an-cnpmnc" alt="visitor badge"/>
### <img src="https://media.giphy.com/media/VgCDAzcKvsR6OM0uWg/giphy.gif" width="50"> A little more about project...  

```javascript
const vinhkyit.tech/cps = {
            project-name: "Dien thoai All-in",
            scrum-master: "HoangTrieu",
            project-manager: "VinhKyIT",
            developer: ["VinhKyIT, HoangTrieu, ThayPhapHuTi"],
            technologies: {
                frontEnd: {
                    js: "Node, PugJS",
                    css: ["materialize", "bootstrap"]
                },
                backEnd: {
                    js: ["node", "express"],
                database: "mongoDB",
                },
            },
            quote: "Tien co kiem nhu nuoc roi cung se troi het"
        };
```

<img src="https://media.giphy.com/media/LnQjpWaON8nhr21vNW/giphy.gif" width="60"> <em><b>I love connecting with different people</b> so if you want to say <b>hi, I'll be happy to meet you more!</b> 😊</em>

---

⭐️ From [@vinhkyit](https://github.com/vinhkyit)
